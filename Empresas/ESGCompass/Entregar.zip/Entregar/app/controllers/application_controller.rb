# frozen_string_literal: true

# Application-wide controller
class ApplicationController < ActionController::Base
end
