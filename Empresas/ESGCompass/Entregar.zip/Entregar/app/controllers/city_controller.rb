class CityController < ApplicationController
  def index
  end
end
