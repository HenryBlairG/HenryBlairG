# frozen_string_literal: true

# Application-wide helper
module ApplicationHelper
end
